import flask
import numpy as np

def test_function() :
	t = np.arange(1, 10)
	print(t)
	
if __name__ == "__main__":
	test_function()
